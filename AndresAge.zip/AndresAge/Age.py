from flask import Flask, request, jsonify
from datetime import datetime
from dateutil.relativedelta import relativedelta

app = Flask(__name__)

@app.route('/resource', methods=['GET', 'POST'])
def conversion():
    if request.method == 'POST':
        try:
            current_date = datetime.now()

            data = request.get_json()

            birthDateStr = data.get('birthDate')

            if not birthDateStr:
                return jsonify({'error': 'Missing birthDate in request'})

            birthDate = datetime.strptime(birthDateStr, "%d-%m-%Y")

            year = birthDate.year

            bisiesto = leapYear(year)

            age = relativedelta(current_date, birthDate).years

            print(birthDateStr)
            print(bisiesto)
            print(age)

            
            return jsonify({'age': age,'leap':bisiesto})

        except ValueError:
            return jsonify({'error': 'Invalid date format. Use DD-MM-YYYY'})
        except TypeError:
            return jsonify({'error': 'Invalid data type in request'})
        except Exception as e:
            return jsonify({'error': str(e)})
    
    return jsonify({'error': 'Use POST method'})

def leapYear(year):
    if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
        return 'bisiesto'
    else:
        return 'no bisiesto'

if __name__ == "__main__":
    app.run()
