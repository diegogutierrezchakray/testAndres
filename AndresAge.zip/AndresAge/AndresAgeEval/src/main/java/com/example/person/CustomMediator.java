package com.example.person;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.synapse.MessageContext; 
import org.apache.synapse.mediators.AbstractMediator;
import org.json.JSONObject;
import org.apache.synapse.core.axis2.Axis2MessageContext;
import org.apache.synapse.commons.json.JsonUtil;

public class CustomMediator extends AbstractMediator { 
    public boolean mediate(MessageContext context){
        try {
            org.apache.axis2.context.MessageContext axis2MessageContext = ((Axis2MessageContext) context).getAxis2MessageContext();
            log.info(axis2MessageContext);
            JSONObject jsonPayload = new JSONObject(JsonUtil.jsonPayloadToString(axis2MessageContext));

            String birthDate = jsonPayload.optString("birthDate");
            String name = jsonPayload.optString("name");
            String middleName = jsonPayload.optString("middleName");
            String lastName = jsonPayload.optString("lastName");
            log.info(birthDate);
            JSONObject birthdatePayload = new JSONObject();
            birthdatePayload.put("birthDate", birthDate);
            log.info(birthdatePayload);

            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpPost httpPost = new HttpPost("http://localhost:5000/resource");
            httpPost.setHeader("Content-Type", "application/json");

            StringEntity stringEntity = new StringEntity(birthdatePayload.toString());
            httpPost.setEntity(stringEntity);
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                HttpEntity responseEntity = response.getEntity();
                String responseString = EntityUtils.toString(responseEntity);
                log.info("resp"+responseString);
                
                JsonUtil.newJsonPayload(axis2MessageContext,responseString,true,true);
            }
    }catch(Exception e){
        log.error(e);
    }

        return true;
    }

}
