package org.acme;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import java.util.HashMap;
import java.util.Map;

@Path("/resource")
public class GreetingResource {

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Map<String, String> processAge(Map<String, Object> payload) {
        Map<String, String> response = new HashMap<>();
        System.out.println("Received payload: " + payload);

        if (payload.containsKey("age")) {
            Object ageObject = payload.get("age");
            Integer age = null;

            if (ageObject instanceof Number) {
                age = ((Number) ageObject).intValue();
            } else if (ageObject instanceof String) {
                try {
                    age = Integer.parseInt((String) ageObject);
                } catch (NumberFormatException e) {
                    response.put("error", "Age value is not a valid number");
                    return response;
                }
            } else {
                response.put("error", "Age value is not a number");
                return response;
            }

            if (age != null) {
                String result;
                if (age > 26) {
                    result = age + " , Andres es menor";
                } else if (age < 26) {
                    result = age + " , Andres es mayor";
                } else {
                    result = "misma edad";
                }
                response.put("res", result);
            } else {
                response.put("error", "Age value is null");
            }
        } else {
            response.put("error", "Missing 'age' in request");
        }

        return response;
    }
}
